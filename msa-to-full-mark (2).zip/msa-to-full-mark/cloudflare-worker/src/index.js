// Cloudflare Worker: يقف بين التطبيق وGemini API عشان مفتاح الـ API
// يفضل مخزن هنا بس (كـ secret) وميتنشرش جوه الـ APK خالص.

const SYSTEM_INSTRUCTION = `أنت "MSA To Full Mark"، مساعد دراسي ذكي باللغة العربية.
ضوابط صارمة يجب الالتزام بها دائمًا:
1) رد فقط على الأسئلة والمحتوى الدراسي أو التعليمي (شرح دروس، حل تمارين وأسئلة امتحانات، تلخيص مناهج، تحليل ملفات PDF أو صور دراسية، تلخيص محاضرات).
2) إذا كانت الرسالة لا علاقة لها بالدراسة أو المنهج (دردشة عامة، أسئلة شخصية، مواضيع غير تعليمية)، ارفض بأدب بجملة قصيرة توضح أنك مساعد دراسي فقط، ولا تجاوب على السؤال نفسه مهما كان.
3) عند حل سؤال، اشرح خطوات الحل بشكل واضح ومنظم قبل ذكر الإجابة النهائية.
4) عند تحليل ملف (PDF أو صورة)، استخدم محتواه فقط للإجابة ولا تخترع معلومات غير موجودة فيه.
5) اكتب دائمًا باللغة العربية الفصحى المبسطة إلا لو طُلب منك غير ذلك.`;

const MODEL = "gemini-2.0-flash";
const MAX_BODY_BYTES = 15 * 1024 * 1024; // 15MB safety cap per request

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type"
};

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") {
      return new Response(null, { headers: corsHeaders });
    }

    if (request.method !== "POST") {
      return json({ error: "Method not allowed" }, 405);
    }

    const contentLength = Number(request.headers.get("content-length") || 0);
    if (contentLength > MAX_BODY_BYTES) {
      return json({ error: "الطلب كبير جدًا" }, 413);
    }

    let payload;
    try {
      payload = await request.json();
    } catch (e) {
      return json({ error: "JSON غير صالح" }, 400);
    }

    const parts = payload && payload.parts;
    if (!Array.isArray(parts) || parts.length === 0) {
      return json({ error: "parts مفقودة" }, 400);
    }

    const geminiBody = {
      system_instruction: { parts: [{ text: SYSTEM_INSTRUCTION }] },
      contents: [{ role: "user", parts }]
    };

    const geminiRes = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": env.GEMINI_API_KEY
        },
        body: JSON.stringify(geminiBody)
      }
    );

    const text = await geminiRes.text();
    return new Response(text, {
      status: geminiRes.status,
      headers: { "Content-Type": "application/json", ...corsHeaders }
    });
  }
};

function json(obj, status) {
  return new Response(JSON.stringify(obj), {
    status: status || 200,
    headers: { "Content-Type": "application/json", ...corsHeaders }
  });
}
