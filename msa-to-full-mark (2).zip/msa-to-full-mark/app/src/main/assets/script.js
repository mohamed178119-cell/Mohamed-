// ======================= CONFIG =======================
// ملحوظة: مفيش أي مفتاح API هنا. التطبيق بيكلم الـ proxy بتاعنا
// على Cloudflare Worker، وهو اللي بيحتفظ بالمفتاح ويكلم Gemini بالنيابة عنا.
// غيّر الرابط ده بعد أول نشر للـ Worker (هتلاقيه في نتيجة الـ GitHub Action
// أو في لوحة تحكم Cloudflare).
const PROXY_URL = "https://msa-full-mark-proxy.mohamed178119.workers.dev";

// ملحوظة: الضابط اللي بيمنع الرد على أي حاجة خارج الدراسة موجود
// دلوقتي في الـ Cloudflare Worker بس، مش هنا، عشان محدش يقدر يتخطاه
// بتعديل كود التطبيق.

// ======================= STATE =======================
let lastUploadedFilePart = null; // { inlineData: { mimeType, data } }
let mediaRecorder = null;
let audioChunks = [];
let isRecording = false;

// ======================= NAVIGATION =======================
document.querySelectorAll(".nav-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".nav-btn").forEach(b => b.classList.remove("active"));
    document.querySelectorAll(".screen").forEach(s => s.classList.remove("active"));
    btn.classList.add("active");
    const name = btn.dataset.screen;
    document.getElementById("screen-" + name).classList.add("active");
    const titles = { upload: "رفع المذاكرة", record: "التسجيل الصوتي", features: "مميزات التطبيق" };
    document.getElementById("screen-title").textContent = titles[name];
  });
});

// ======================= HELPERS =======================
function addBubble(logId, text, type) {
  const log = document.getElementById(logId);
  const div = document.createElement("div");
  div.className = "bubble " + type;
  div.textContent = text;
  log.appendChild(div);
  log.scrollTop = log.scrollHeight;
  return div;
}

function addPdfLink(bubbleDiv, title, content) {
  const link = document.createElement("div");
  link.className = "pdf-download";
  link.textContent = "⬇️ تحميل كـ PDF";
  link.onclick = () => downloadAsPdf(title, content);
  bubbleDiv.appendChild(link);
}

function downloadAsPdf(title, content) {
  try {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    const lines = doc.splitTextToSize(content, 180);
    doc.setFontSize(11);
    doc.text(lines, 15, 20);
    doc.save((title || "msa-note").slice(0, 40) + ".pdf");
  } catch (e) {
    alert("تعذر إنشاء ملف PDF على هذا الجهاز");
  }
}

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result.split(",")[1]);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

async function callGemini(parts) {
  const res = await fetch(PROXY_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ parts })
  });
  if (!res.ok) {
    const errText = await res.text();
    throw new Error("خطأ من الخادم: " + res.status + " " + errText.slice(0, 200));
  }
  const data = await res.json();
  const text = data?.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("\n").trim();
  return text || "معلش، محصلش رد مفهوم من المساعد.";
}

// ======================= SCREEN 1: UPLOAD =======================
const fileInput = document.getElementById("file-input");
const fileNameEl = document.getElementById("file-name");
const uploadQuestion = document.getElementById("upload-question");
const uploadSendBtn = document.getElementById("upload-send");

fileInput.addEventListener("change", async () => {
  const file = fileInput.files[0];
  if (!file) return;
  fileNameEl.textContent = "⏳ جاري تجهيز الملف: " + file.name;
  try {
    const base64 = await fileToBase64(file);
    lastUploadedFilePart = { inlineData: { mimeType: file.type || "application/pdf", data: base64 } };
    fileNameEl.textContent = "✅ " + file.name;
    addBubble("chat-log-upload", "تم رفع الملف: " + file.name + " — اسأل أي سؤال عنه", "system");
  } catch (e) {
    fileNameEl.textContent = "";
    addBubble("chat-log-upload", "تعذر قراءة الملف", "system");
  }
});

uploadSendBtn.addEventListener("click", sendUploadMessage);
uploadQuestion.addEventListener("keydown", e => { if (e.key === "Enter") sendUploadMessage(); });

async function sendUploadMessage() {
  const question = uploadQuestion.value.trim();
  if (!question) return;
  addBubble("chat-log-upload", question, "user");
  uploadQuestion.value = "";
  uploadSendBtn.disabled = true;
  const thinking = addBubble("chat-log-upload", "جاري التفكير...", "bot");

  try {
    const parts = [];
    if (lastUploadedFilePart) parts.push(lastUploadedFilePart);
    parts.push({ text: question });

    const answer = await callGemini(parts);
    thinking.textContent = answer;
    addPdfLink(thinking, question, answer);
  } catch (e) {
    thinking.textContent = "حصل خطأ: " + e.message;
  } finally {
    uploadSendBtn.disabled = false;
  }
}

// ======================= SCREEN 2: RECORDING =======================
const recordToggleBtn = document.getElementById("record-toggle");
const audioFileInput = document.getElementById("audio-file-input");
const recordStatus = document.getElementById("record-status");

recordToggleBtn.addEventListener("click", async () => {
  if (!isRecording) {
    await startRecording();
  } else {
    stopRecording();
  }
});

async function startRecording() {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    audioChunks = [];
    mediaRecorder = new MediaRecorder(stream);
    mediaRecorder.ondataavailable = e => audioChunks.push(e.data);
    mediaRecorder.onstop = async () => {
      const blob = new Blob(audioChunks, { type: mediaRecorder.mimeType || "audio/webm" });
      stream.getTracks().forEach(t => t.stop());
      await processAudioBlob(blob);
    };
    mediaRecorder.start();
    isRecording = true;
    recordToggleBtn.textContent = "⏹️ إيقاف التسجيل";
    recordToggleBtn.classList.add("recording");
    recordStatus.textContent = "جاري التسجيل...";
  } catch (e) {
    recordStatus.textContent = "تعذر الوصول للمايكروفون";
  }
}

function stopRecording() {
  if (mediaRecorder && isRecording) {
    mediaRecorder.stop();
    isRecording = false;
    recordToggleBtn.textContent = "🎙️ ابدأ التسجيل";
    recordToggleBtn.classList.remove("recording");
    recordStatus.textContent = "جاري المعالجة...";
  }
}

audioFileInput.addEventListener("change", async () => {
  const file = audioFileInput.files[0];
  if (!file) return;
  recordStatus.textContent = "جاري معالجة الملف الصوتي...";
  await processAudioBlob(file);
});

async function processAudioBlob(blobOrFile) {
  addBubble("chat-log-record", "🎧 تسجيل صوتي جديد", "user");
  const thinking = addBubble("chat-log-record", "جاري تحويل الصوت لنص...", "bot");
  try {
    const base64 = await fileToBase64(blobOrFile);
    const mimeType = blobOrFile.type || "audio/webm";

    // الخطوة 1: تفريغ نصي حرفي للتسجيل
    const transcript = await callGemini([
      { inlineData: { mimeType, data: base64 } },
      { text: "فرّغ هذا التسجيل الصوتي نصيًا بشكل حرفي كامل باللغة العربية، بدون أي تلخيص أو تعليق." }
    ]);

    thinking.textContent = "📝 النص المفرّغ:\n" + transcript;

    // الخطوة 2: تلخيص دراسي للنص المفرّغ
    const summaryThinking = addBubble("chat-log-record", "جاري التلخيص...", "bot");
    const summary = await callGemini([
      { text: "لخّص النص الدراسي التالي في نقاط مرتبة وواضحة تساعد الطالب على المذاكرة:\n\n" + transcript }
    ]);
    summaryThinking.textContent = "📌 الملخص:\n" + summary;
    addPdfLink(summaryThinking, "ملخص التسجيل", summary);

    recordStatus.textContent = "تم ✅";
  } catch (e) {
    thinking.textContent = "حصل خطأ: " + e.message;
    recordStatus.textContent = "";
  }
}
