# MSA To Full Mark

تطبيق أندرويد لمساعد دراسي ذكي (package: `com.msa.fullmark`).
مفتاح Gemini مش متسجل جوه التطبيق - فيه Cloudflare Worker بيحتفظ بيه بدل كده.

## الرفع من الموبايل (من غير ما ترفع كل ملف لوحده)

هترفع بس **3 حاجات** على الريبو، مش كل الملفات واحد واحد:

### 1) اعمل ملفين الـ workflows يدويًا (نسخ ولصق)

من صفحة الريبو في GitHub (المتصفح): **Add file → Create new file**

- في خانة اسم الملف اكتب بالظبط: `.github/workflows/build.yml`
  (لما تكتب الـ / كده GitHub بيعمل الفولدرات لوحده)
  والصق فيه محتوى ملف `build.yml` اللي جوه الزيب المرفق، واعمل Commit.
- كرر نفس الخطوة لملف: `.github/workflows/deploy-worker.yml`
  والصق فيه محتوى ملف `deploy-worker.yml`.

### 2) ارفع الزيب نفسه كملف واحد بس

من **Add file → Upload files**، اختار ملف `msa-to-full-mark.zip` (من غير ما
تفكه) وارفعه في جذر الريبو مباشرة، واعمل Commit.

الـ workflows اتظبطوا عشان يفكوا الزيب لوحدهم وقت التشغيل.

### 3) الـ secrets

من **Settings → Secrets and variables → Actions** ضيف:
- `CLOUDFLARE_API_TOKEN`
- `CLOUDFLARE_ACCOUNT_ID`
- `GEMINI_API_KEY`

(اعمل حساب مجاني على Cloudflare لو معندكش، والتوكن من My Profile → API Tokens
→ Create Token → template "Edit Cloudflare Workers"، والـ Account ID من
صفحة Workers & Pages الرئيسية.)

### 4) شغّل الـ workflows بالترتيب

1. من تبويب **Actions**: شغّل **Deploy Worker Proxy** الأول.
2. بعد النجاح، روح Cloudflare Dashboard → Workers & Pages، وانسخ رابط
   الـ Worker (`msa-full-mark-proxy.اسمك.workers.dev`) وابعتهولي — هظبطلك
   الزيب بالرابط الصح وترفعه تاني (خطوة 2) بدل القديم.
3. بعد كده شغّل **Build APK**، وهتلاقي الـ APK جاهز في Artifacts.

## الشاشات

1. **رفع مذاكرة** – رفع PDF أو صورة وسؤال المساعد عنها (بيرفض أي سؤال خارج الدراسة).
2. **التسجيل الصوتي** – تسجيل مباشر أو رفع تسجيل، وتحويله لنص ثم تلخيصه.
3. **المميزات** – صفحة تعريفية بالتطبيق + اسم المصمم محمد سعد.

## الأمان

- الضابط اللي بيمنع الرد على أي حاجة خارج الدراسة موجود جوه الـ Worker بس.
- مفتاح Gemini موجود كـ secret جوه Cloudflare بس، وميتسجلش في أي كود بيتنشر.
