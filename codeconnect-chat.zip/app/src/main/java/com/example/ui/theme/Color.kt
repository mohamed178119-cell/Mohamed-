package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Colors
val TealPrimary = Color(0xFF0F766E)
val TealOnPrimary = Color(0xFFFFFFFF)
val TealPrimaryContainer = Color(0xFFCCFBF1)
val TealOnPrimaryContainer = Color(0xFF115E59)

val IndigoSecondary = Color(0xFF4F46E5)
val IndigoOnSecondary = Color(0xFFFFFFFF)
val IndigoSecondaryContainer = Color(0xFFE0E7FF)
val IndigoOnSecondaryContainer = Color(0xFF3730A3)

val AmberTertiary = Color(0xFFD97706)
val AmberOnTertiary = Color(0xFFFFFFFF)
val AmberTertiaryContainer = Color(0xFFFEF3C7)
val AmberOnTertiaryContainer = Color(0xFF92400E)

val SlateBackgroundLight = Color(0xFFF8FAFC)
val SlateSurfaceLight = Color(0xFFFFFFFF)
val SlateSurfaceVariantLight = Color(0xFFF1F5F9)
val SlateOnBackgroundLight = Color(0xFF0F172A)
val SlateOnSurfaceLight = Color(0xFF1E293B)
val SlateOutlineLight = Color(0xFFCBD5E1)

// Dark Theme Colors
val TealPrimaryDark = Color(0xFF2DD4BF)
val TealOnPrimaryDark = Color(0xFF042F2E)
val TealPrimaryContainerDark = Color(0xFF134E4A)
val TealOnPrimaryContainerDark = Color(0xFF99F6E4)

val IndigoSecondaryDark = Color(0xFF818CF8)
val IndigoOnSecondaryDark = Color(0xFF1E1B4B)
val IndigoSecondaryContainerDark = Color(0xFF312E81)
val IndigoOnSecondaryContainerDark = Color(0xFFC7D2FE)

val AmberTertiaryDark = Color(0xFFFBBF24)
val AmberOnTertiaryDark = Color(0xFF451A03)
val AmberTertiaryContainerDark = Color(0xFF78350F)
val AmberOnTertiaryContainerDark = Color(0xFFFDE68A)

val SlateBackgroundDark = Color(0xFF0B1120)
val SlateSurfaceDark = Color(0xFF1E293B)
val SlateSurfaceVariantDark = Color(0xFF334155)
val SlateOnBackgroundDark = Color(0xFFF8FAFC)
val SlateOnSurfaceDark = Color(0xFFE2E8F0)
val SlateOutlineDark = Color(0xFF475569)

// Status & Chat Colors
val OnlineGreen = Color(0xFF10B981)
val OfflineGray = Color(0xFF64748B)
val SentBubbleLight = Color(0xFF0D9488)
val ReceivedBubbleLight = Color(0xFFF1F5F9)
val SentBubbleDark = Color(0xFF0F766E)
val ReceivedBubbleDark = Color(0xFF334155)
val DesignerGold = Color(0xFFEAB308)
val DesignerGoldDark = Color(0xFFFACC15)

