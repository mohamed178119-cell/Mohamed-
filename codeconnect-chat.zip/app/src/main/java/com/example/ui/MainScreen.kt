package com.example.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.outlined.AccountCircle
import androidx.compose.material.icons.outlined.Forum
import androidx.compose.material.icons.outlined.GroupAdd
import androidx.compose.material.icons.outlined.Key
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.ChatDetailScreen
import com.example.ui.screens.ChatsScreen
import com.example.ui.screens.ConnectScreen
import com.example.ui.screens.CreateGroupScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.viewmodel.ChatViewModel
import com.example.ui.viewmodel.MainTab

@Composable
fun MainScreen(
    viewModel: ChatViewModel,
    modifier: Modifier = Modifier
) {
    val currentTab by viewModel.currentTab.collectAsState()
    val activeChat by viewModel.activeChat.collectAsState()
    val incomingRequests by viewModel.incomingRequests.collectAsState()
    val snackbarMessage by viewModel.snackbarMessage.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(snackbarMessage) {
        snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    // Force RTL layout direction for natural Arabic reading and alignment
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            bottomBar = {
                if (activeChat == null) {
                    NavigationBar(
                        modifier = Modifier.navigationBarsPadding(),
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 6.dp
                    ) {
                        // Tab 1: Chats
                        NavigationBarItem(
                            selected = currentTab == MainTab.CHATS,
                            onClick = { viewModel.selectTab(MainTab.CHATS) },
                            icon = {
                                Icon(
                                    imageVector = if (currentTab == MainTab.CHATS) Icons.Filled.Forum else Icons.Outlined.Forum,
                                    contentDescription = "المحادثات",
                                    modifier = Modifier.size(24.dp)
                                )
                            },
                            label = {
                                Text(
                                    text = "المحادثات",
                                    fontSize = 11.sp,
                                    fontWeight = if (currentTab == MainTab.CHATS) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        )

                        // Tab 2: Connect & Requests
                        NavigationBarItem(
                            selected = currentTab == MainTab.CONNECT,
                            onClick = { viewModel.selectTab(MainTab.CONNECT) },
                            icon = {
                                BadgedBox(badge = {
                                    if (incomingRequests.isNotEmpty()) {
                                        Badge(
                                            containerColor = MaterialTheme.colorScheme.error,
                                            contentColor = MaterialTheme.colorScheme.onError
                                        ) {
                                            Text("${incomingRequests.size}")
                                        }
                                    }
                                }) {
                                    Icon(
                                        imageVector = if (currentTab == MainTab.CONNECT) Icons.Filled.Key else Icons.Outlined.Key,
                                        contentDescription = "الاتصال",
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            },
                            label = {
                                Text(
                                    text = "الاتصال والأكواد",
                                    fontSize = 11.sp,
                                    fontWeight = if (currentTab == MainTab.CONNECT) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        )

                        // Tab 3: Create Group
                        NavigationBarItem(
                            selected = currentTab == MainTab.CREATE_GROUP,
                            onClick = { viewModel.selectTab(MainTab.CREATE_GROUP) },
                            icon = {
                                Icon(
                                    imageVector = if (currentTab == MainTab.CREATE_GROUP) Icons.Filled.GroupAdd else Icons.Outlined.GroupAdd,
                                    contentDescription = "إنشاء مجموعة",
                                    modifier = Modifier.size(24.dp)
                                )
                            },
                            label = {
                                Text(
                                    text = "مجموعة صحاب",
                                    fontSize = 11.sp,
                                    fontWeight = if (currentTab == MainTab.CREATE_GROUP) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        )

                        // Tab 4: Designer & Profile
                        NavigationBarItem(
                            selected = currentTab == MainTab.PROFILE,
                            onClick = { viewModel.selectTab(MainTab.PROFILE) },
                            icon = {
                                Icon(
                                    imageVector = if (currentTab == MainTab.PROFILE) Icons.Filled.AccountCircle else Icons.Outlined.AccountCircle,
                                    contentDescription = "الملف والمصمم",
                                    modifier = Modifier.size(24.dp)
                                )
                            },
                            label = {
                                Text(
                                    text = "المصمم والملف",
                                    fontSize = 11.sp,
                                    fontWeight = if (currentTab == MainTab.PROFILE) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        )
                    }
                }
            },
            modifier = modifier.fillMaxSize()
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (activeChat != null) {
                    ChatDetailScreen(
                        chat = activeChat!!,
                        viewModel = viewModel
                    )
                } else {
                    AnimatedContent(
                        targetState = currentTab,
                        transitionSpec = { fadeIn() togetherWith fadeOut() },
                        label = "MainTabsNavigation"
                    ) { targetTab ->
                        when (targetTab) {
                            MainTab.CHATS -> ChatsScreen(viewModel = viewModel)
                            MainTab.CONNECT -> ConnectScreen(viewModel = viewModel)
                            MainTab.CREATE_GROUP -> CreateGroupScreen(viewModel = viewModel)
                            MainTab.PROFILE -> ProfileScreen(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }
}
