package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.ChatConversation
import com.example.data.model.ChatMessage
import com.example.data.model.ChatRequest
import com.example.data.model.ChatType
import com.example.data.model.MessageType
import com.example.data.model.QuickContact
import com.example.data.model.UserProfile
import com.example.data.repository.ChatRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class MainTab(val titleAr: String, val index: Int) {
    CHATS("المحادثات", 0),
    CONNECT("الاتصال والطلبات", 1),
    CREATE_GROUP("إنشاء مجموعة", 2),
    PROFILE("الملف والمصمم", 3)
}

enum class ChatFilter {
    ALL,
    DIRECT,
    GROUPS
}

class ChatViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    private val repository = ChatRepository(database)

    val quickDemoContacts: List<QuickContact> = repository.quickDemoContacts

    // Current navigation tab
    private val _currentTab = MutableStateFlow(MainTab.CHATS)
    val currentTab: StateFlow<MainTab> = _currentTab.asStateFlow()

    // Active open chat conversation (null if on main screens)
    private val _activeChatId = MutableStateFlow<String?>(null)
    val activeChatId: StateFlow<String?> = _activeChatId.asStateFlow()

    // Search and filter
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _chatFilter = MutableStateFlow(ChatFilter.ALL)
    val chatFilter: StateFlow<ChatFilter> = _chatFilter.asStateFlow()

    // UI Feedback messages
    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    // Data streams from repository
    val userProfile: StateFlow<UserProfile> = repository.getUserProfile()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserProfile())

    private val rawChats: StateFlow<List<ChatConversation>> = repository.getChats()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val incomingRequests: StateFlow<List<ChatRequest>> = repository.getIncomingRequests()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val sentRequests: StateFlow<List<ChatRequest>> = repository.getSentRequests()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filtered chats based on tab and search
    val filteredChats: StateFlow<List<ChatConversation>> = combine(
        rawChats,
        _searchQuery,
        _chatFilter
    ) { chats, query, filter ->
        chats.filter { chat ->
            val matchesFilter = when (filter) {
                ChatFilter.ALL -> true
                ChatFilter.DIRECT -> chat.type == ChatType.DIRECT
                ChatFilter.GROUPS -> chat.type == ChatType.GROUP
            }
            val matchesQuery = query.isBlank() ||
                    chat.title.contains(query, ignoreCase = true) ||
                    chat.code.contains(query, ignoreCase = true) ||
                    chat.lastMessage.contains(query, ignoreCase = true)

            matchesFilter && matchesQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active chat messages stream
    private val _activeChatMessages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val activeChatMessages: StateFlow<List<ChatMessage>> = _activeChatMessages.asStateFlow()

    private val _activeChat = MutableStateFlow<ChatConversation?>(null)
    val activeChat: StateFlow<ChatConversation?> = _activeChat.asStateFlow()

    init {
        viewModelScope.launch {
            repository.initializeDefaultDataIfNeeded()
        }
    }

    fun selectTab(tab: MainTab) {
        _currentTab.value = tab
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setChatFilter(filter: ChatFilter) {
        _chatFilter.value = filter
    }

    fun openChat(chat: ChatConversation) {
        _activeChatId.value = chat.id
        _activeChat.value = chat
        viewModelScope.launch {
            repository.markChatAsRead(chat.id)
            repository.getMessages(chat.id).collect { messages ->
                _activeChatMessages.value = messages
            }
        }
    }

    fun closeChat() {
        _activeChatId.value = null
        _activeChat.value = null
        _activeChatMessages.value = emptyList()
    }

    // Connect & Request Actions
    fun sendRequest(targetCode: String, note: String) {
        viewModelScope.launch {
            val result = repository.sendConnectionRequest(targetCode, note)
            result.onSuccess { msg ->
                _snackbarMessage.value = msg
            }.onFailure { err ->
                _snackbarMessage.value = err.message ?: "حدث خطأ أثناء إرسال الطلب"
            }
        }
    }

    fun acceptRequest(request: ChatRequest) {
        viewModelScope.launch {
            val newChatId = repository.acceptRequest(request)
            _snackbarMessage.value = "تم قبول المحادثة مع ${request.fromName} بنجاح! تم إنشاء محادثة خاصة."
            // Open the new chat automatically
            rawChats.value.find { it.id == newChatId }?.let { newChat ->
                openChat(newChat)
            }
        }
    }

    fun rejectRequest(request: ChatRequest) {
        viewModelScope.launch {
            repository.rejectRequest(request.id)
            _snackbarMessage.value = "تم رفض طلب المحادثة"
        }
    }

    // Create Group Action ("أنشأ مجموعه صحابه")
    fun createGroup(
        name: String,
        codes: List<String>,
        description: String,
        colorHex: Long,
        onSuccess: (String) -> Unit
    ) {
        viewModelScope.launch {
            val result = repository.createGroup(name, codes, description, colorHex)
            result.onSuccess { newChatId ->
                _snackbarMessage.value = "تم إنشاء مجموعة الصحاب ($name) بنجاح! 🎉"
                onSuccess(newChatId)
                _currentTab.value = MainTab.CHATS
            }.onFailure { err ->
                _snackbarMessage.value = err.message ?: "فشل إنشاء المجموعة"
            }
        }
    }

    // Chat Messaging Actions
    fun sendTextMessage(content: String) {
        val chatId = _activeChatId.value ?: return
        if (content.isBlank()) return
        viewModelScope.launch {
            repository.sendMessage(chatId, content, MessageType.TEXT)
        }
    }

    fun sendVoiceMessage(durationSec: Int = 4) {
        val chatId = _activeChatId.value ?: return
        viewModelScope.launch {
            repository.sendMessage(
                chatId = chatId,
                content = "تسجيل صوتي",
                messageType = MessageType.VOICE,
                audioDuration = durationSec
            )
        }
    }

    fun sendCodeShare(codeToShare: String) {
        val chatId = _activeChatId.value ?: return
        viewModelScope.launch {
            repository.sendMessage(
                chatId = chatId,
                content = codeToShare,
                messageType = MessageType.CODE_SHARE
            )
        }
    }

    // Profile & Settings Actions
    fun toggleOnlineOffline(isOnline: Boolean) {
        viewModelScope.launch {
            repository.setOnlineMode(isOnline)
            _snackbarMessage.value = if (isOnline) {
                "تم تفعيل الوضع الأونلاين - متصل بالشبكة والمزامنة التلقائية 🌐"
            } else {
                "تم تفعيل وضع الأوفلاين - حفظ الرسائل محلياً بدون إنترنت 📴"
            }
        }
    }

    fun regenerateCode() {
        viewModelScope.launch {
            val newCode = repository.regenerateMyCode()
            _snackbarMessage.value = "تم تحديث الكود الخاص بك إلى: $newCode"
        }
    }

    fun updateProfile(name: String, status: String, avatar: String) {
        viewModelScope.launch {
            repository.updateProfile(name, status, avatar)
            _snackbarMessage.value = "تم تحديث بيانات الملف الشخصي بنجاح"
        }
    }

    fun resetDemoData() {
        viewModelScope.launch {
            repository.resetAllData()
            _snackbarMessage.value = "تم إعادة تعيين البيانات والمحادثات التجريبية بنجاح"
        }
    }

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }
}
