package com.example.data.model

enum class ChatType {
    DIRECT,
    GROUP
}

enum class RequestStatus {
    PENDING,
    ACCEPTED,
    REJECTED
}

enum class MessageType {
    TEXT,
    VOICE,
    CODE_SHARE,
    GROUP_ACTION
}

data class ChatConversation(
    val id: String,
    val type: ChatType,
    val title: String,
    val code: String, // target friend code or group code
    val memberCodes: List<String> = emptyList(),
    val avatarColorHex: Long = 0xFF0D9488,
    val lastMessage: String = "",
    val lastTimestamp: Long = System.currentTimeMillis(),
    val unreadCount: Int = 0,
    val isAccepted: Boolean = true,
    val isOnline: Boolean = true
)

data class ChatMessage(
    val id: String,
    val chatId: String,
    val senderName: String,
    val senderCode: String,
    val content: String,
    val messageType: MessageType = MessageType.TEXT,
    val timestamp: Long = System.currentTimeMillis(),
    val isMine: Boolean = true,
    val isDelivered: Boolean = true,
    val isRead: Boolean = true,
    val isOfflinePending: Boolean = false,
    val audioDurationSec: Int = 0
)

data class ChatRequest(
    val id: String,
    val fromCode: String,
    val fromName: String,
    val toCode: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    val status: RequestStatus = RequestStatus.PENDING,
    val isIncoming: Boolean = true
)

data class UserProfile(
    val id: Int = 1,
    val myCode: String = "MS-2026",
    val myName: String = "محمد سعد",
    val myStatus: String = "متاح للتواصل ومصمم التطبيقات",
    val myAvatarEmoji: String = "⚡",
    val isOnlineMode: Boolean = true,
    val notificationsEnabled: Boolean = true
)

data class QuickContact(
    val code: String,
    val name: String,
    val avatarEmoji: String,
    val description: String
)
