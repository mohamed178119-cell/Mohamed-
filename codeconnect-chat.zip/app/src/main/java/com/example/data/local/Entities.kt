package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.ChatType
import com.example.data.model.MessageType
import com.example.data.model.RequestStatus

@Entity(tableName = "chats")
data class ChatEntity(
    @PrimaryKey val id: String,
    val type: String, // DIRECT or GROUP
    val title: String,
    val code: String,
    val memberCodesJson: String, // comma-separated codes
    val avatarColorHex: Long,
    val lastMessage: String,
    val lastTimestamp: Long,
    val unreadCount: Int = 0,
    val isAccepted: Boolean = true,
    val isOnline: Boolean = true
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey val id: String,
    val chatId: String,
    val senderName: String,
    val senderCode: String,
    val content: String,
    val messageType: String, // TEXT, VOICE, CODE_SHARE, GROUP_ACTION
    val timestamp: Long,
    val isMine: Boolean,
    val isDelivered: Boolean,
    val isRead: Boolean,
    val isOfflinePending: Boolean,
    val audioDurationSec: Int = 0
)

@Entity(tableName = "requests")
data class RequestEntity(
    @PrimaryKey val id: String,
    val fromCode: String,
    val fromName: String,
    val toCode: String,
    val message: String,
    val timestamp: Long,
    val status: String, // PENDING, ACCEPTED, REJECTED
    val isIncoming: Boolean
)

@Entity(tableName = "user_profile")
data class ProfileEntity(
    @PrimaryKey val id: Int = 1,
    val myCode: String,
    val myName: String,
    val myStatus: String,
    val myAvatarEmoji: String,
    val isOnlineMode: Boolean,
    val notificationsEnabled: Boolean
)
