package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.ChatEntity
import com.example.data.local.MessageEntity
import com.example.data.local.ProfileEntity
import com.example.data.local.RequestEntity
import com.example.data.model.ChatConversation
import com.example.data.model.ChatMessage
import com.example.data.model.ChatRequest
import com.example.data.model.ChatType
import com.example.data.model.MessageType
import com.example.data.model.QuickContact
import com.example.data.model.RequestStatus
import com.example.data.model.UserProfile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.util.UUID

class ChatRepository(private val database: AppDatabase) {
    private val chatDao = database.chatDao()
    private val messageDao = database.messageDao()
    private val requestDao = database.requestDao()
    private val profileDao = database.profileDao()

    val quickDemoContacts = listOf(
        QuickContact("AHMED-101", "أحمد علي", "👨‍💻", "مطور برمجيات - متاح للدردشة"),
        QuickContact("SARA-202", "سارة خالد", "🎨", "مصممة واجهات وتجربة مستخدم"),
        QuickContact("OMAR-303", "عمر محمود", "🚀", "صديق مقرب - مهتم بالتقنية"),
        QuickContact("NOUR-404", "نور الهدى", "📚", "كاتبة محتوى وباحثة"),
        QuickContact("TARIQ-505", "طارق يوسف", "💡", "مؤسس مشاريع ناشئة")
    )

    suspend fun initializeDefaultDataIfNeeded() {
        val currentProfile = profileDao.getProfileDirect()
        if (currentProfile == null) {
            // 1. Initial User Profile (Designer showcase / default user)
            profileDao.insertOrUpdateProfile(
                ProfileEntity(
                    id = 1,
                    myCode = "MS-2026",
                    myName = "محمد سعد",
                    myStatus = "متاح للتواصل • صانع تطبيق تواصل كود",
                    myAvatarEmoji = "⭐",
                    isOnlineMode = true,
                    notificationsEnabled = true
                )
            )

            // 2. Initial Sample Direct Chat
            val chat1Id = "chat_ahmed_101"
            val chat2Id = "chat_group_friends"

            val initialChats = listOf(
                ChatEntity(
                    id = chat1Id,
                    type = ChatType.DIRECT.name,
                    title = "أحمد علي",
                    code = "AHMED-101",
                    memberCodesJson = "AHMED-101",
                    avatarColorHex = 0xFF0F766E,
                    lastMessage = "أهلاً يا محمد! الكود الخاص بيك شغال ممتاز، التطبيق سريع جداً 🚀",
                    lastTimestamp = System.currentTimeMillis() - 1000 * 60 * 15,
                    unreadCount = 1,
                    isAccepted = true,
                    isOnline = true
                ),
                ChatEntity(
                    id = chat2Id,
                    type = ChatType.GROUP.name,
                    title = "شلة الصحاب والعمل 👥",
                    code = "GRP-SHALLETNA",
                    memberCodesJson = "AHMED-101,OMAR-303,NOUR-404,MS-2026",
                    avatarColorHex = 0xFF4F46E5,
                    lastMessage = "عمر محمود: تم إنشاء المجموعة بنجاح عن طريق إضافة أكواد الأصدقاء! مرحباً بالجميع 🎉",
                    lastTimestamp = System.currentTimeMillis() - 1000 * 60 * 5,
                    unreadCount = 0,
                    isAccepted = true,
                    isOnline = true
                )
            )
            chatDao.insertAll(initialChats)

            // 3. Initial Messages
            val initialMessages = listOf(
                MessageEntity(
                    id = UUID.randomUUID().toString(),
                    chatId = chat1Id,
                    senderName = "محمد سعد",
                    senderCode = "MS-2026",
                    content = "السلام عليكم يا أحمد، أرسلت لك طلباً بالكود الخاص بك للتجربة.",
                    messageType = MessageType.TEXT.name,
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 20,
                    isMine = true,
                    isDelivered = true,
                    isRead = true,
                    isOfflinePending = false
                ),
                MessageEntity(
                    id = UUID.randomUUID().toString(),
                    chatId = chat1Id,
                    senderName = "أحمد علي",
                    senderCode = "AHMED-101",
                    content = "وعليكم السلام يا محمد! وافقت على الطلب فوراً. النظام عازل كل دردشة لوحدها بشكل ممتاز ومريح جداً 👌",
                    messageType = MessageType.TEXT.name,
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 18,
                    isMine = false,
                    isDelivered = true,
                    isRead = true,
                    isOfflinePending = false
                ),
                MessageEntity(
                    id = UUID.randomUUID().toString(),
                    chatId = chat1Id,
                    senderName = "أحمد علي",
                    senderCode = "AHMED-101",
                    content = "أهلاً يا محمد! الكود الخاص بيك شغال ممتاز، التطبيق سريع جداً 🚀",
                    messageType = MessageType.TEXT.name,
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 15,
                    isMine = false,
                    isDelivered = true,
                    isRead = false,
                    isOfflinePending = false
                ),
                // Group messages
                MessageEntity(
                    id = UUID.randomUUID().toString(),
                    chatId = chat2Id,
                    senderName = "النظام",
                    senderCode = "SYSTEM",
                    content = "تم إنشاء المجموعة بواسطة محمد سعد مع الأكواد (AHMED-101, OMAR-303, NOUR-404)",
                    messageType = MessageType.GROUP_ACTION.name,
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 10,
                    isMine = false,
                    isDelivered = true,
                    isRead = true,
                    isOfflinePending = false
                ),
                MessageEntity(
                    id = UUID.randomUUID().toString(),
                    chatId = chat2Id,
                    senderName = "عمر محمود",
                    senderCode = "OMAR-303",
                    content = "عمر محمود: تم إنشاء المجموعة بنجاح عن طريق إضافة أكواد الأصدقاء! مرحباً بالجميع 🎉",
                    messageType = MessageType.TEXT.name,
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 5,
                    isMine = false,
                    isDelivered = true,
                    isRead = true,
                    isOfflinePending = false
                )
            )
            messageDao.insertMessages(initialMessages)

            // 4. Initial Incoming Requests (Demonstrates: recipient must accept before chat starts!)
            val initialRequests = listOf(
                RequestEntity(
                    id = "req_sara_202",
                    fromCode = "SARA-202",
                    fromName = "سارة خالد",
                    toCode = "MS-2026",
                    message = "مرحباً محمد! أدخلت كودك الخاص وأود بدء محادثة معك بخصوص تصميم واجهات التطبيق الجديدة 🎨",
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 30,
                    status = RequestStatus.PENDING.name,
                    isIncoming = true
                ),
                RequestEntity(
                    id = "req_tariq_505",
                    fromCode = "TARIQ-505",
                    fromName = "طارق يوسف",
                    toCode = "MS-2026",
                    message = "السلام عليكم، حصلت على كود التواصل الخاص بك وأرغب في مناقشة فكرة مشروع مشترك.",
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 120,
                    status = RequestStatus.PENDING.name,
                    isIncoming = true
                )
            )
            requestDao.insertAll(initialRequests)
        }
    }

    // Flows
    fun getChats(): Flow<List<ChatConversation>> {
        return chatDao.getAllChats().map { entities ->
            entities.map { it.toDomain() }
        }
    }

    fun getChatById(chatId: String): Flow<ChatConversation?> {
        return chatDao.getChatById(chatId).map { it?.toDomain() }
    }

    fun getMessages(chatId: String): Flow<List<ChatMessage>> {
        return messageDao.getMessagesForChat(chatId).map { entities ->
            entities.map { it.toDomain() }
        }
    }

    fun getIncomingRequests(): Flow<List<ChatRequest>> {
        return requestDao.getPendingIncomingRequests().map { entities ->
            entities.map { it.toDomain() }
        }
    }

    fun getSentRequests(): Flow<List<ChatRequest>> {
        return requestDao.getSentRequests().map { entities ->
            entities.map { it.toDomain() }
        }
    }

    fun getUserProfile(): Flow<UserProfile> {
        return profileDao.getProfile().map { entity ->
            entity?.toDomain() ?: UserProfile()
        }
    }

    // Send Request by Code
    suspend fun sendConnectionRequest(
        targetCode: String,
        noteMessage: String
    ): Result<String> {
        val trimmedCode = targetCode.trim().uppercase()
        if (trimmedCode.isBlank()) {
            return Result.failure(Exception("يرجى إدخال كود صحيح"))
        }

        val profile = profileDao.getProfileDirect() ?: UserProfile().toEntity()
        if (trimmedCode == profile.myCode.uppercase()) {
            return Result.failure(Exception("لا يمكنك إدخال الكود الخاص بك! أدخل كود صديق."))
        }

        // Find demo name or fallback
        val matchedContact = quickDemoContacts.find { it.code.uppercase() == trimmedCode }
        val contactName = matchedContact?.name ?: "مستخدم الكود ($trimmedCode)"

        val requestId = "req_sent_${UUID.randomUUID()}"
        val request = RequestEntity(
            id = requestId,
            fromCode = profile.myCode,
            fromName = profile.myName,
            toCode = trimmedCode,
            message = if (noteMessage.isBlank()) "مرحباً! أدخلت كودك وأود التواصل معك." else noteMessage,
            timestamp = System.currentTimeMillis(),
            status = RequestStatus.PENDING.name,
            isIncoming = false
        )
        requestDao.insertRequest(request)

        // If in online mode, simulate smart peer acceptance after a short delay
        if (profile.isOnlineMode) {
            CoroutineScope(Dispatchers.IO).launch {
                delay(3000)
                // Simulate approval by the peer
                requestDao.updateRequestStatus(requestId, RequestStatus.ACCEPTED.name)
                
                // Create dedicated chat room for this user
                val newChatId = "chat_${trimmedCode.lowercase().replace("-", "_")}_${UUID.randomUUID().toString().take(6)}"
                val newChat = ChatEntity(
                    id = newChatId,
                    type = ChatType.DIRECT.name,
                    title = contactName,
                    code = trimmedCode,
                    memberCodesJson = trimmedCode,
                    avatarColorHex = 0xFF0D9488,
                    lastMessage = "وافق الطرف الآخر على بدء المحادثة معك عبر الكود! 🎉",
                    lastTimestamp = System.currentTimeMillis(),
                    unreadCount = 1,
                    isAccepted = true,
                    isOnline = true
                )
                chatDao.insertOrUpdateChat(newChat)

                // Add greeting message
                val greetingMsg = MessageEntity(
                    id = UUID.randomUUID().toString(),
                    chatId = newChatId,
                    senderName = contactName,
                    senderCode = trimmedCode,
                    content = "مرحباً يا ${profile.myName}! استلمت طلبك عبر الكود ($trimmedCode) ووافقت عليه. يسعدني التواصل معك! ✨",
                    messageType = MessageType.TEXT.name,
                    timestamp = System.currentTimeMillis(),
                    isMine = false,
                    isDelivered = true,
                    isRead = false,
                    isOfflinePending = false
                )
                messageDao.insertMessage(greetingMsg)
            }
        }

        return Result.success("تم إرسال طلب المحادثة بنجاح إلى $trimmedCode")
    }

    // Accept Incoming Request -> Creates a separate isolated chat for that person
    suspend fun acceptRequest(request: ChatRequest): String {
        requestDao.updateRequestStatus(request.id, RequestStatus.ACCEPTED.name)

        val profile = profileDao.getProfileDirect() ?: UserProfile().toEntity()
        val newChatId = "chat_${request.fromCode.lowercase().replace("-", "_")}_${UUID.randomUUID().toString().take(6)}"
        
        val newChat = ChatEntity(
            id = newChatId,
            type = ChatType.DIRECT.name,
            title = request.fromName,
            code = request.fromCode,
            memberCodesJson = request.fromCode,
            avatarColorHex = 0xFF0F766E,
            lastMessage = "تم قبول طلب المحادثة بنجاح، يمكنكما الآن بدء الدردشة! ✨",
            lastTimestamp = System.currentTimeMillis(),
            unreadCount = 0,
            isAccepted = true,
            isOnline = profile.isOnlineMode
        )
        chatDao.insertOrUpdateChat(newChat)

        // Add the request message as first incoming message
        val welcomeMessage = MessageEntity(
            id = UUID.randomUUID().toString(),
            chatId = newChatId,
            senderName = request.fromName,
            senderCode = request.fromCode,
            content = request.message,
            messageType = MessageType.TEXT.name,
            timestamp = request.timestamp,
            isMine = false,
            isDelivered = true,
            isRead = true,
            isOfflinePending = false
        )
        messageDao.insertMessage(welcomeMessage)

        // Add automatic system acceptance announcement
        val systemMsg = MessageEntity(
            id = UUID.randomUUID().toString(),
            chatId = newChatId,
            senderName = "النظام",
            senderCode = "SYSTEM",
            content = "تمت الموافقة على بدء المحادثة الفردية الخاصة بالكود (${request.fromCode}) بنجاح.",
            messageType = MessageType.GROUP_ACTION.name,
            timestamp = System.currentTimeMillis(),
            isMine = false,
            isDelivered = true,
            isRead = true,
            isOfflinePending = false
        )
        messageDao.insertMessage(systemMsg)

        return newChatId
    }

    // Reject Incoming Request
    suspend fun rejectRequest(requestId: String) {
        requestDao.updateRequestStatus(requestId, RequestStatus.REJECTED.name)
    }

    // Create Group from Multiple Codes ("أنشأ مجموعه صحابه")
    suspend fun createGroup(
        groupName: String,
        codesList: List<String>,
        description: String,
        avatarColorHex: Long = 0xFF4F46E5
    ): Result<String> {
        val trimmedName = groupName.trim()
        if (trimmedName.isBlank()) {
            return Result.failure(Exception("يرجى إدخال اسم للمجموعة"))
        }

        val cleanedCodes = codesList.map { it.trim().uppercase() }.filter { it.isNotBlank() }.distinct()
        if (cleanedCodes.isEmpty()) {
            return Result.failure(Exception("يرجى إدخال كود صديق واحد على الأقل للمجموعة"))
        }

        val profile = profileDao.getProfileDirect() ?: UserProfile().toEntity()
        val allMemberCodes = (cleanedCodes + profile.myCode).distinct()
        val groupChatId = "grp_${UUID.randomUUID().toString().take(8)}"
        val groupCode = "GRP-${(1000..9999).random()}"

        val groupEntity = ChatEntity(
            id = groupChatId,
            type = ChatType.GROUP.name,
            title = trimmedName,
            code = groupCode,
            memberCodesJson = allMemberCodes.joinToString(","),
            avatarColorHex = avatarColorHex,
            lastMessage = "تم إنشاء مجموعة الصحاب بنجاح مع ${cleanedCodes.size} من الأصدقاء 🎉",
            lastTimestamp = System.currentTimeMillis(),
            unreadCount = 0,
            isAccepted = true,
            isOnline = profile.isOnlineMode
        )
        chatDao.insertOrUpdateChat(groupEntity)

        // Insert System Action Message
        val systemMsg = MessageEntity(
            id = UUID.randomUUID().toString(),
            chatId = groupChatId,
            senderName = "النظام",
            senderCode = "SYSTEM",
            content = "أنشأ ${profile.myName} المجموعة ($trimmedName) مع الأكواد: ${cleanedCodes.joinToString(", ")}",
            messageType = MessageType.GROUP_ACTION.name,
            timestamp = System.currentTimeMillis(),
            isMine = false,
            isDelivered = true,
            isRead = true,
            isOfflinePending = false
        )
        messageDao.insertMessage(systemMsg)

        if (description.isNotBlank()) {
            val descMsg = MessageEntity(
                id = UUID.randomUUID().toString(),
                chatId = groupChatId,
                senderName = profile.myName,
                senderCode = profile.myCode,
                content = "📌 وصف المجموعة: $description",
                messageType = MessageType.TEXT.name,
                timestamp = System.currentTimeMillis() + 10,
                isMine = true,
                isDelivered = true,
                isRead = true,
                isOfflinePending = false
            )
            messageDao.insertMessage(descMsg)
        }

        return Result.success(groupChatId)
    }

    // Send Message
    suspend fun sendMessage(
        chatId: String,
        content: String,
        messageType: MessageType = MessageType.TEXT,
        audioDuration: Int = 0
    ) {
        val profile = profileDao.getProfileDirect() ?: UserProfile().toEntity()
        val isOnline = profile.isOnlineMode

        val msgId = UUID.randomUUID().toString()
        val message = MessageEntity(
            id = msgId,
            chatId = chatId,
            senderName = profile.myName,
            senderCode = profile.myCode,
            content = content,
            messageType = messageType.name,
            timestamp = System.currentTimeMillis(),
            isMine = true,
            isDelivered = isOnline,
            isRead = isOnline,
            isOfflinePending = !isOnline,
            audioDurationSec = audioDuration
        )
        messageDao.insertMessage(message)

        val preview = when (messageType) {
            MessageType.VOICE -> "🎤 تسجيل صوتي ($audioDuration ثانية)"
            MessageType.CODE_SHARE -> "🔑 كود تواصل: $content"
            else -> content
        }
        chatDao.updateLastMessage(chatId, preview, System.currentTimeMillis())

        // If online, simulate peer response
        if (isOnline) {
            triggerSimulatedPeerReply(chatId, content, messageType)
        }
    }

    private fun triggerSimulatedPeerReply(chatId: String, userMessage: String, type: MessageType) {
        CoroutineScope(Dispatchers.IO).launch {
            delay(1500)
            val chat = chatDao.getChatByIdDirect(chatId) ?: return@launch
            val isGroup = chat.type == ChatType.GROUP.name

            val responderName = if (isGroup) {
                listOf("أحمد علي", "سارة خالد", "عمر محمود", "نور الهدى").random()
            } else {
                chat.title
            }
            val responderCode = if (isGroup) "CODE-${(100..999).random()}" else chat.code

            val replies = listOf(
                "أهلاً وسهلاً! رسالتك وصلت بكل وضوح عبر الكود ✨",
                "تمام يا بطل! الفكرة ممتازة جداً ومتحمسين نكمل 🚀",
                "أنا موجود أونلاين، تسلم على التواصل الجميل 🙏",
                "نظام التواصل بالأكواد والمجموعات شغال بشكل ممتاز وسريع جداً 💯",
                "معاك تماماً، بالتوفيق دائماً!"
            )
            val replyText = replies.random()

            val replyMsg = MessageEntity(
                id = UUID.randomUUID().toString(),
                chatId = chatId,
                senderName = responderName,
                senderCode = responderCode,
                content = if (isGroup) "$responderName: $replyText" else replyText,
                messageType = MessageType.TEXT.name,
                timestamp = System.currentTimeMillis(),
                isMine = false,
                isDelivered = true,
                isRead = true,
                isOfflinePending = false
            )
            messageDao.insertMessage(replyMsg)
            chatDao.updateLastMessage(chatId, replyMsg.content, System.currentTimeMillis(), unreadCount = 0)
        }
    }

    // Toggle Online / Offline Mode
    suspend fun setOnlineMode(isOnline: Boolean) {
        profileDao.updateOnlineStatus(isOnline)
        if (isOnline) {
            // Flush offline pending messages
            val pending = messageDao.getOfflinePendingMessages()
            for (msg in pending) {
                messageDao.markMessageSynced(msg.id)
                triggerSimulatedPeerReply(msg.chatId, msg.content, MessageType.valueOf(msg.messageType))
            }
        }
    }

    // Regenerate My Code
    suspend fun regenerateMyCode(): String {
        val newCode = "MS-${(1000..9999).random()}"
        profileDao.updateMyCode(newCode)
        return newCode
    }

    // Update Profile
    suspend fun updateProfile(name: String, status: String, avatar: String) {
        val current = profileDao.getProfileDirect() ?: UserProfile().toEntity()
        profileDao.insertOrUpdateProfile(
            current.copy(
                myName = name,
                myStatus = status,
                myAvatarEmoji = avatar
            )
        )
    }

    suspend fun markChatAsRead(chatId: String) {
        chatDao.markChatAsRead(chatId)
    }

    suspend fun deleteChat(chatId: String) {
        chatDao.deleteChat(chatId)
        messageDao.deleteMessagesForChat(chatId)
    }

    suspend fun resetAllData() {
        chatDao.clearAll()
        messageDao.clearAll()
        requestDao.clearAll()
        initializeDefaultDataIfNeeded()
    }

    // Mappers
    private fun ChatEntity.toDomain() = ChatConversation(
        id = id,
        type = ChatType.valueOf(type),
        title = title,
        code = code,
        memberCodes = if (memberCodesJson.isBlank()) emptyList() else memberCodesJson.split(","),
        avatarColorHex = avatarColorHex,
        lastMessage = lastMessage,
        lastTimestamp = lastTimestamp,
        unreadCount = unreadCount,
        isAccepted = isAccepted,
        isOnline = isOnline
    )

    private fun MessageEntity.toDomain() = ChatMessage(
        id = id,
        chatId = chatId,
        senderName = senderName,
        senderCode = senderCode,
        content = content,
        messageType = try { MessageType.valueOf(messageType) } catch (e: Exception) { MessageType.TEXT },
        timestamp = timestamp,
        isMine = isMine,
        isDelivered = isDelivered,
        isRead = isRead,
        isOfflinePending = isOfflinePending,
        audioDurationSec = audioDurationSec
    )

    private fun RequestEntity.toDomain() = ChatRequest(
        id = id,
        fromCode = fromCode,
        fromName = fromName,
        toCode = toCode,
        message = message,
        timestamp = timestamp,
        status = try { RequestStatus.valueOf(status) } catch (e: Exception) { RequestStatus.PENDING },
        isIncoming = isIncoming
    )

    private fun ProfileEntity.toDomain() = UserProfile(
        id = id,
        myCode = myCode,
        myName = myName,
        myStatus = myStatus,
        myAvatarEmoji = myAvatarEmoji,
        isOnlineMode = isOnlineMode,
        notificationsEnabled = notificationsEnabled
    )

    private fun UserProfile.toEntity() = ProfileEntity(
        id = id,
        myCode = myCode,
        myName = myName,
        myStatus = myStatus,
        myAvatarEmoji = myAvatarEmoji,
        isOnlineMode = isOnlineMode,
        notificationsEnabled = notificationsEnabled
    )
}
